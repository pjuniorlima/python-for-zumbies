#!/usr/bin/python3.3

C = int(input("Digite a temperatura em Celsius:"))
fahr = (9*C/5) + 32
print("A temperatura convertida é {0} Fahrenheit".format(fahr))
