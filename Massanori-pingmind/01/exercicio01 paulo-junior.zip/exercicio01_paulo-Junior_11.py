#!/usr/bin/python3.3

print("Calculando quantos algarismos tem 2**1000000")
print("2**1000000 tem", len(str(2**1000000)), "algarismos.")
