#!/usr/bin/python3.3


metros = int(input("Digite o número a ser convertido:"))
milimetros = metros*1000
print("O número convertido é: %dmm" %milimetros)
