#!/usr/bin/python3.3

F = int(input("Digite a temperatura em Fahrenheit:"))
C = F*5/9 - 160/9
print("A temperatura convertida é %d Celsius" %C)
