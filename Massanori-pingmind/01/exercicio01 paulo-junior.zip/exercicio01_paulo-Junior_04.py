#!/usr/bin/python3.3

salario = int(input("Digite o salário:"))
aumento = int(input("Digite a porcentagem de aumento:"))

print(salario*(1+(aumento/100)))
