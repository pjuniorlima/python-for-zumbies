def desconto(preço):
    return 0.9*preço
